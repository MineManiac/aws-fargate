exports.handler = async (event) => {
    console.log("Hello, World!");
  
    const response = {
      statusCode: 200,
      body: "Hello, World!",
    };
  
    return response;
  };